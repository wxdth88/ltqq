/*
 * 联通十周年「充值享会员」— 抢 QQ 超级会员（一年档）
 *
 * 活动：2026-11-01 10:00:00 ~ 2026-11-14 23:59:59
 * 目标：QQ超级会员「充值300元送12个月」（giftCode 26101311）
 *
 * 完整流程：query 查状态 → chargePre 锁单(抢名额) → 收短信 → 输验证码 → 完成充值
 * 本脚本负责最关键的前两步：10:00:00 秒级锁定名额；最后的充值需手动输一次短信验证码。
 *
 * ─────────────────────────────────────────────────────────────
 * 青龙环境变量：
 *   LT_COOKIE      登录后的完整 Cookie（必填）
 *   LT_GIFT_CODE   指定 giftCode（可选，默认自动选一年档 26101311）
 *   LT_TARGET_TIME 精准抢购时间 HH:MM:SS（默认 10:00:00）
 *   LT_PRECISE     是否开启"等到整点秒抢" 1=开(默认) 0=关
 *   LT_OFFSET_MS   发请求提前/延后的毫秒偏移（默认 0，正值=提前）
 *
 * 定时任务（二选一，推荐前者）：
 *   ① cron: 58 9 * * *   → 9:58 启动，脚本自己等到 10:00:00.000 秒抢（配合 LT_PRECISE=1）
 *   ② cron: 0 10 * * *   → 10:00 触发直接抢（最简单，但秒级精度略差）
 * ─────────────────────────────────────────────────────────────
 */

const axios = require('axios');

const BASE = 'https://kapi.10010.com/app-charge353-activity/kcard-10th-anniversary';
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';

const cookie = (process.env.LT_COOKIE || '').trim();
const forcedGiftCode = (process.env.LT_GIFT_CODE || '').trim();
const targetTime = process.env.LT_TARGET_TIME || '10:00:00';
const precise = (process.env.LT_PRECISE || '1') === '1';
const offsetMs = Number(process.env.LT_OFFSET_MS || '0') || 0;

// 状态枚举（模块67导出）
const STATUS = {1:'未开始', 2:'已结束', 3:'未登录', 4:'无资格', 5:'未充值', 6:'充值中', 7:'已成功', 8:'已锁定'};
// chargePre 错误码
const ERR = {
  B0101: '会员信息已更新，请重新选择',
  B0102: '库存已告罄（售罄）',
  B0103: '您已充值成功，请勿重复充值',
  B0104: '您已锁定其他会员，请先完成已锁定的充值',
  B0105: '充值处理中，请稍候',
  '501': '活动太火爆，请稍后重试',
};

let lines = [];
const log = s => { const t = `[${new Date().toLocaleString('zh-CN', {hour12: false})}] ${s}`; console.log(t); lines.push(t); };

async function api(path, body) {
  const { data } = await axios.post(`${BASE}/${path}`, body, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Origin': 'https://txwk.10010.com',
      'Referer': 'https://txwk.10010.com/',
      'User-Agent': UA,
      'Cookie': cookie,
    },
    timeout: 10000,
  });
  return data;
}

function notify() {
  const title = '联通十周年·抢QQ超级会员';
  const content = lines.join('\n');
  for (const mod of ['sendNotify', './sendNotify']) {
    try {
      const m = require(mod);
      const fn = m.sendNotify || m.default || m;
      if (typeof fn === 'function') { fn(title, content); return; }
    } catch (e) {}
  }
  console.log('\n===== 通知（未接入青龙推送，仅日志）=====\n' + content);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// 等到目标时间整点（含毫秒偏移）—— 粗睡 + 忙等，卡 ±1~2ms
async function waitUntil(hms) {
  const [hh, mm, ss] = hms.split(':').map(Number);
  const now = new Date();
  const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, ss, 0);
  if (target <= now) { log(`ℹ️ 已过 ${hms}，不再等待，直接抢。`); return; }
  const fireAt = target.getTime() + offsetMs;
  log(`⏳ 精准抢购：目标 ${hms}，偏移 ${offsetMs}ms，约 ${((fireAt - Date.now()) / 1000).toFixed(1)} 秒后发起（±2ms）`);
  // ① 先粗睡到 fireAt - 30ms，避开长定时器的调度延迟
  const coarse = fireAt - Date.now() - 30;
  if (coarse > 0) await sleep(coarse);
  // ② 高精度忙等到 fireAt（忙等约 30ms，代价可接受）
  while (Date.now() < fireAt) {}
  log(`🕐 已到点 ${hms}，实际偏差 ${Date.now() - fireAt}ms`);
}

// 从 giftInfos 选 QQ超级会员一年档
function pickGift(gifts) {
  if (forcedGiftCode) {
    const g = gifts.find(x => x.giftCode === forcedGiftCode);
    if (!g) log(`❌ 未找到指定 giftCode=${forcedGiftCode}（可能无资格/无货）`);
    return g || null;
  }
  let qq = gifts.filter(x => (x.giftName || '').includes('QQ超级会员'));
  if (!qq.length) { log('❌ 本次活动未匹配到 QQ超级会员 档位，请检查 giftInfos。'); return null; }
  log('🎯 命中 QQ超级会员 档位：' + qq.map(x => `${x.giftCode}(${x.month}个月/¥${(x.payamount/100).toFixed(0)})`).join(' | '));
  // 优先 month 大（12=一年档，即充300送一年）
  qq.sort((a, b) => (Number(b.month) || 0) - (Number(a.month) || 0) || (Number(b.payamount) || 0) - (Number(a.payamount) || 0));
  return qq[0];
}

(async () => {
  try {
    if (!cookie) { log('❌ 未配置 LT_COOKIE，请先获取登录 Cookie。'); throw new Error('no cookie'); }

    // ① 查询
    const q = await api('query', '{}');
    if (!q || q.code !== '00000') { log(`❌ 查询失败 code=${q && q.code} msg=${q && q.msg}`); notify(); return; }
    const d = q.data || {};
    const status = Number(d.status) || 0;
    log(`✅ 查询成功 phone=${d.phone} status=${status}(${STATUS[status] || '未知'}) chargeStatus=${d.chargeStatus}`);
    if (d.prizeName) log(`🎁 资格：${d.prizeName}`);

    // ② 状态判断
    if (status === 3) { log('❌ Cookie 已失效，请重新登录页面抓取新 Cookie 填入 LT_COOKIE。'); notify(); return; }
    if (status === 2) { log('ℹ️ 活动已结束。'); notify(); return; }
    if (status === 4) { log('❌ 当前号码无活动参与资格。'); notify(); return; }
    if (status === 7) { log('✅ 已充值成功，无需重复抢。'); notify(); return; }

    // ③ 选目标
    const gifts = d.giftInfos || [];
    const target = pickGift(gifts);
    if (!target) { notify(); return; }
    log(`🎯 目标：${target.giftName} giftCode=${target.giftCode} ${target.month}个月 充值¥${(target.payamount/100).toFixed(0)} stockStatus=${target.stockStatus} lockRemain=${target.lockRemainSeconds}`);

    // 已锁定 / 充值中 → 无需再抢
    const locked = String(target.stockStatus) !== '2'
      && (Number(d.chargeStatus) === 6 || (target.lockRemainSeconds != null && Number(target.lockRemainSeconds) >= 0));
    if (locked) { log('ℹ️ 已锁定该会员，锁定期内请尽快手动完成充值（需短信验证码）。'); notify(); return; }

    // 售罄预判（若已过抢购时间手动跑时能第一时间发现）
    if (String(target.stockStatus) === '2') {
      log('⚠️ 当前该会员 stockStatus=2 已售罄。若未到 10 点请等待开抢；若已售罄则明日 10:00 再试。');
      notify(); return;
    }

    // ④ 精准等时（可选）
    if (precise) await waitUntil(targetTime);

    // ⑤ 锁单抢名额
    const r = await api('chargePre', `giftCode=${target.giftCode}`);
    if (r && r.code === '00000') {
      log('🎉 锁单成功！已抢到 QQ超级会员(一年档) 名额，请尽快到活动页完成充值（收短信→输验证码→充值300元），锁定期内有效。');
    } else {
      const code = r && r.code;
      log(`⚠️ 锁单失败 code=${code} msg=${(r && r.msg)} ${code ? '(' + (ERR[code] || '') + ')' : ''}`);
    }
  } catch (e) {
    log('❌ 异常：' + (e && e.response ? JSON.stringify(e.response.data || {}) : (e && e.message ? e.message : String(e))));
  } finally {
    notify();
  }
})();